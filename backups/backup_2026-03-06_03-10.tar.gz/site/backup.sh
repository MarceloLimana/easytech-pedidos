#!/bin/bash

DATE=$(date +"%Y-%m-%d_%H-%M")

PROJECT_DIR="/home/sushi/clientes/sushiinhouse"
BACKUP_DIR="$PROJECT_DIR/backups"
TEMP_DIR="/tmp/backup_easytech"

mkdir -p $BACKUP_DIR
rm -rf $TEMP_DIR
mkdir -p $TEMP_DIR

echo "🚀 Iniciando backup completo..."

# =========================
# Backup do site
# =========================

echo "📦 Backup do site"
cp -r /home/sushi/clientes/sushiinhouse $TEMP_DIR/site

# =========================
# Backup PostgreSQL
# =========================

echo "🗄 Backup do PostgreSQL"

docker exec projeto-garantia-db-garantia-1 \
pg_dump -U postgres postgres > $TEMP_DIR/database.sql

# =========================
# Backup N8N
# =========================

echo "⚙ Backup N8N"

docker cp projeto-garantia-n8n-1:/home/node/.n8n $TEMP_DIR/n8n_data

# =========================
# Backup Docker Compose
# =========================

echo "🐳 Backup docker-compose"

cp /home/marcelo/projeto-garantia/docker-compose.yml $TEMP_DIR/

# =========================
# Backup Nginx
# =========================

echo "🌐 Backup nginx"

docker cp npm-app-1:/data $TEMP_DIR/nginx_config

# =========================
# Compactar backup
# =========================

echo "🗜 Compactando backup..."

tar -czf $BACKUP_DIR/backup_$DATE.tar.gz -C $TEMP_DIR .

rm -rf $TEMP_DIR

echo "✅ Backup criado: backup_$DATE.tar.gz"

# =========================
# Manter apenas 7 backups
# =========================

cd $BACKUP_DIR

ls -t backup_*.tar.gz | tail -n +8 | xargs rm -f

echo "🧹 Limpeza de backups antigos concluída"

# =========================
# Enviar para GitHub
# =========================

cd $PROJECT_DIR

git add backups/*
git commit -m "backup automático $DATE"
git push

echo "☁ Backup enviado para GitHub"
